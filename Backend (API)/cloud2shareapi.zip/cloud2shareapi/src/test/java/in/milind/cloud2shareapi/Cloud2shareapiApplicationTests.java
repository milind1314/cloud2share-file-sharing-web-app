package in.milind.cloud2shareapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cloud2shareapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
