package in.milind.cloud2shareapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cloud2shareapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cloud2shareapiApplication.class, args);
	}

}
